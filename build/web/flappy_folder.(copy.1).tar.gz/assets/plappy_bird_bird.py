import pygame


class bird(pygame.sprite.Sprite):
    def __init__(self,):
        super(bird,self).__init__()
        self.bird_1 = pygame.image.load("birdup.png").convert_alpha()
        self.bird_2 = pygame.image.load("birddown.png").convert_alpha()

        self.bird_1_size = pygame.transform.scale(self.bird_1,(55,50))
        self.bird_2_size = pygame.transform.scale(self.bird_2,(55,50))

        self.bird_1_rect = self.bird_1.get_rect()
        self.bird_2_rect = self.bird_2.get_rect()

        self.bird_image_list = [self.bird_1_size,self.bird_2_size]
        self.image_index = 0
        self.image = self.bird_image_list[self.image_index]
        self.image_rec = self.image.get_rect(center=(80,400))
        self.fly_speed = 25000
        self.animation_counter = 0
        self.y = float(self.image_rec.y)

        self.y_velocity= 0.0

        self.gravity = 1000
    def bird_motion(self, dt):
        self.y_velocity += self.gravity*dt

        self.y += self.y_velocity*dt

        self.image_rec.y = round(self.y)

    def fly(self, dt):
        self.y_velocity = -self.fly_speed*dt

    def animation(self):
        self.animation_counter += 1

        if self.animation_counter >= 5 :
            self.image = self.bird_image_list[self.image_index]
            if self.image_index == 0:
                self.image_index = 1
            else :
                self.image_index = 0
                
            self.animation_counter = 0

    def roof(self):

        if self.image_rec.y < 0:
            self.image_rec.y = 0
            self.y = 0.0
            self.y_velocity = 0

    def resetpos(self):
        self.image_index = 0
        self.y_velocity= 0.0
        self.image_rec = self.image.get_rect(center=(80,400))
        self.y = float(self.image_rec.y)



 
