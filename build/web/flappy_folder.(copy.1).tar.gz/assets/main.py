import asyncio
import pygame
import os
import sys,time
from plappy_bird_pipe import pipe
from plappy_bird_bird import bird

os.environ["SDL_VIDEO_CENTERED"]= "1"

class flore:
    def __init__(self, screen, flore_speed):
        self.flore_speed = flore_speed
        self.screen = screen
        self.flore = pygame.image.load("ground.png").convert_alpha()
        self.flore_2 = pygame.image.load("ground.png").convert_alpha()
        self.flore_size = pygame.transform.scale(self.flore, (550,250))
        self.flore_2_size = pygame.transform.scale(self.flore,(550,250))
        self.flore_pos = 0
        self.flore_rect = self.flore_size.get_rect()
        self.flore_2_rect = self.flore_2_size.get_rect()
        self.flore_2_pos = float(self.flore_rect.right)
        self.flore_rect.y = 650
        self.flore_2_rect.y = self.flore_rect.y
       

    def flore_movement(self, dt):
        self.flore_pos -= int(self.flore_speed*dt)
        self.flore_2_pos-= int(self.flore_speed*dt)

        width = self.flore_size.get_width()

        if self.flore_pos + width < 0:
            self.flore_pos = self.flore_2_pos + width

        if self.flore_2_pos + width<0:
            self.flore_2_pos = self.flore_pos + width

    def draw(self):

        self.flore_rect.x = round(self.flore_pos)
        self.flore_2_rect.x = round(self.flore_2_pos)
        self.screen.blit(self.flore_size, self.flore_rect)
        self.screen.blit(self.flore_size,self.flore_2_rect)


class game:
    def __init__(self):
        pygame.init()
        self.window_higth = 800
        self.window_width = 550
        self.flore_speed = 250
        self.parant_screen = pygame.display.set_mode((self.window_width, self.window_higth),pygame.SCALED ,vsync= 1)
        self.backgrownd = pygame.image.load("bg.png").convert()
        self.backgrownd_size = pygame.transform.scale( self.backgrownd ,(600 ,801))
        self.bird = bird()
        self.flore = flore(self.parant_screen, self.flore_speed)
        self.pipes =  []
        self.pipe_genrate_counter = 71
        self.enter_pressed = False
        self.flor_ot_toching = True
        self.running = True
        self.game_over = False
        self.game_margaya = False
        self.score = 0
        self.score_text=pygame.font.SysFont("arial",30)
        self.score_text_rend = self.score_text.render(str(self.score), True,(0,0,0))
        self.is_game_started= True

        self.restart_text=pygame.font.SysFont("arial",30)
        self.restart_text_rend = self.restart_text.render(f"restart", True,(0,0,0))
        self.restart_text_rect = self.restart_text_rend.get_rect(center=(260,650))
        
                  
        self.start_monetoring = False
        self.FPS = pygame.time.Clock()
        self.last_time = time.time()

    def game_over_screen(self):
        if not self.is_game_started:
                self.parant_screen.blit(self.restart_text_rend,self.restart_text_rect)

    
    def draw(self):
        
        self.parant_screen.blit(self.backgrownd_size,(0,0))
        
        self.parant_screen.blit(self.bird.image, self.bird.image_rec)

        for pipe in self.pipes:
            pipe.drowpipe(self.parant_screen)

        self.flore.draw()
        self.chack_score()
        self.parant_screen.blit(self.score_text_rend,(50,30))
        self.game_over_screen()

    def chack_colision(self):
        if len(self.pipes):
            if (self.bird.image_rec.bottom>=650):
                self.enter_pressed = False
                self.is_game_started = False
                self.game_margaya = True

            if (self.bird.image_rec.colliderect(self.pipes[0].pipeup_rect) or self.bird.image_rec.colliderect(self.pipes[0].pipedown_rect)):
                    self.game_over = True
                    self.is_game_started = False
                    self.game_margaya = True


    def flor_toch(self):
        if self.bird.image_rec.bottom>= 650:
            self.bird.image_rec.bottom = 650
            self.flor_ot_toching = False
            self.is_game_started = False
            self.game_margaya = True

 

    def bird_velocity(self, dt):
        self.bird.bird_motion(dt)

    async def run(self):
        while self.running:
            dt = self.FPS.tick(60)/1000.0

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False

                if event.type ==pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE and self.is_game_started:
                        self.enter_pressed = True
                        self.bird.fly(dt)
                        self.flor_toch()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if self.restart_text_rect.collidepoint(pygame.mouse.get_pos()) :
                        self.restart_game()

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE and self.game_margaya:
                        self.restart_game()


            self.update_game(dt)
            await asyncio.sleep(0)


    def restart_game(self):
        self.score = 0
        self.score_text_rend = self.score_text.render(str(self.score), True,(0,0,0))
        self.is_game_started= True
        self.pipe_genrate_counter = 71
        self.enter_pressed = False
        self.bird.resetpos()
        self.game_over = False
        self.pipes.clear()
        self.flor_ot_toching = False
        self.game_margaya = False




    def chack_score(self):
        if len(self.pipes)>0:
            if (self.bird.image_rec.left>self.pipes[0].pipedown_rect.left and
            self.bird.image_rec.right < self.pipes[0].pipedown_rect.right and not self.start_monetoring):
                self.start_monetoring = True
            if self.bird.image_rec.left > self.pipes[0].pipedown_rect.right and self.start_monetoring :
                self.start_monetoring = False
                self.score += 1
                self.parant_screen.blit(self.score_text_rend,(50,30))
                self.score_text_rend = self.score_text.render(str(self.score), True,(0,0,0))

    def update_game(self,dt):
        self.draw()
        pygame.display.flip()

        if self.game_over:
            self.flor_toch()
            self.enter_pressed = False
            if self.flor_ot_toching:
                self.bird.bird_motion(dt)
                self.bird.animation()



        if self.enter_pressed:
            self.chack_colision()
            self.bird.bird_motion(dt)
            self.bird.animation()
            self.pipe_genrate_counter +=1
            self.flore.flore_movement(dt) 
            
            self.bird.roof()
            if self.pipe_genrate_counter >= 80:
                    self.pipes.append(pipe(self.flore_speed , dt))
                    print("pipe crited")
                    self.pipe_genrate_counter = 0
            for p in self.pipes:
                    p.move(dt)

            if  len(self.pipes)!= 0:
                if self.pipes[0].pipeup_rect.right <0:
                    self.pipes.pop(0)
                    print("pipedistroyed")

            
            
            

async def main():
     GAME = game()
     await GAME.run()

if __name__== "__main__":
   
   asyncio.run(main())
#Maplestar
