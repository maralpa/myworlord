import pygame
from random import randint

class pipe:
    def __init__(self, flore_speed,dt):
        self.pipeup = pygame.image.load("pipeup.png").convert_alpha()
        self.pipedown = pygame.image.load("pipedown.png").convert_alpha()
        
        self.pipeup_size = pygame.transform.scale(self.pipeup,(72,400))
        self.pipedown_size = pygame.transform.scale(self.pipedown,(72,380))
        self.pipeup_rect = self.pipeup_size.get_rect()
        self.pipedown_rect = self.pipedown_size.get_rect()
        self.pipe_distance = 170
        self.pipeup_rect.y = randint(250,520)
        self.pipeup_rect.x = 550
        self.pipedown_rect.y = self.pipeup_rect.y-self.pipe_distance-self.pipeup_rect.height
        self.pipedown_rect.x =550
        self.move_speed = flore_speed
    
    def drowpipe(self, win):
        win.blit(self.pipeup_size, self.pipeup_rect)
        win.blit(self.pipedown_size, self.pipedown_rect)

    def move(self, dt):
        self.pipeup_rect.x -= int(self.move_speed*dt)
        self.pipedown_rect.x -= int(self.move_speed*dt)
